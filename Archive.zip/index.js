const form = document.getElementById("contactForm");

function sendEmail() {
    const fullName = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const subject = document.getElementById("subject").value;
    const message = document.getElementById("message").value;

    const bodyMessage = `Full Name: ${fullName}<br> Email: ${email}<br> Phone: ${phone}<br> Subject: ${subject}<br> Message: ${message}<br>`;

    Email.send({
        Host: "smtp.elasticemail.com",
        Username: "medinacleaningcomp@gmail.com",
        Password: "76AB5BC0D1D84C246BD6EDB53753C4F3CADF",
        To: "medinacleaningcomp@gmail.com",
        From: "medinacleaningcomp@gmail.com",
        Subject: subject,
        Body: bodyMessage,
    }).then((message) => {
        alert("Message sent successfully!"); // Display success message
    });
}

function smoothScroll(event) {
    event.preventDefault();
    const targetId = event.target.getAttribute('href');
    const targetElement = document.querySelector(targetId);

    if (targetElement) {
        const offsetTop = targetElement.getBoundingClientRect().top + window.pageYOffset;
        window.scrollTo({
            top: offsetTop,
            behavior: 'smooth'
        });
    }
}

form.addEventListener("submit", (e) => {
    e.preventDefault();
    sendEmail();
});


// Attach smoothScroll to necessary elements here...

    

   function smoothScroll(event) {
    event.preventDefault();
    const targetId = event.target.getAttribute('href');
    const targetElement = document.querySelector(targetId);

    if (targetElement) {
        const offsetTop = targetElement.getBoundingClientRect().top + window.pageYOffset;
        window.scrollTo({
            top: offsetTop,
            behavior: 'smooth'
        });
    }
}





